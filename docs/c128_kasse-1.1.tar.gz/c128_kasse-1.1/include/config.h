#include "general.h"

#ifndef CONFIG_H_
#define CONFIG_H_

#define MAX_ITEMS 16
#define MAX_ITEM_NAME_LENGTH 9
#define MAX_CREDIT_ITEMS 75
#define CREDITS_PER_PAGE 10

/* Eingenommes Geld in Cent */
extern unsigned long int money;
extern unsigned long int items_sold;
extern BYTE printer_port;


/* Datenstruktur der verkauften Eintr�ge */
struct status_t {
	char item_name[MAX_ITEM_NAME_LENGTH+1];
	/* Wieviel kostet der Eintrag (in Cent)? */
	unsigned int price;
	/* Wie oft wurde er verkauft */
	unsigned int times_sold;
};

struct status_array_t {
	BYTE num_items;
	struct status_t status[MAX_ITEMS];
};

/* Datenstruktur f�r die Guthaben */
#define NICKNAME_MAX_LEN 10
struct credits_t {
	char nickname[NICKNAME_MAX_LEN + 1];
	/* Guthaben (in Cent) */
	unsigned int credit;
};

struct credits_array_t {
	BYTE num_items;
	struct credits_t credits[MAX_CREDIT_ITEMS];
};

#ifndef _IS_CONFIG_C
extern struct status_array_t status;
extern struct credits_array_t credits;
#endif

/* L�dt Dinge wie die Druckeradresse */
void load_config();
void load_items();
void load_credits();
//void dump_state();

void save_items();
void save_credits();
#endif /*CONFIG_H_*/
