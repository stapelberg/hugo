#ifndef TIME_H_
#define TIME_H_
void set_time();
char *get_time();
#endif
