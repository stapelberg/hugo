#ifndef CREDIT_MANAGER_H_
#define CREDIT_MANAGER_H_
struct credits_t *find_credit(char *name);
void credit_manager();
#endif
