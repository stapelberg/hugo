
 +-------------------------------------+
 |      C�sarChiffre v1.2              |
 |                                     |
 |      � 2005 Michael Stapelberg      |
 |                                     |
 +-------------------------------------+

 �nderungsliste:

 Version 1.2 (05.10.2005)

   * Neu: Die Option "Gro�-/Kleinschreibung vermischen" wurde eingebaut
   * Neu: Die Option "Leerzeichen entfernen" wurde eingebaut

   * Behoben: Die Alphabeterweiterungen wurden nicht �bernommen, wenn ein Codewort gew�hlt wurde und die Option "Schl�ssel w�hrend dem Chiffrieren verschieben" aktiviert war
   * Behoben: Der verschl�sselte Text wird nun korrekt aktualisiert
   * Behoben: Der Mindest- und Maximalwert f�r die Alphabetverschiebung wird nun korrekt angepasst



 Version 1.1 (01.10.2005)
   * �nderung: Die Option "Starke Verschl�sselung" wurde in "Schl�ssel w�hrend dem Chiffrieren verschieben" umbenannt



 Version 1.0 (30.09.2005)